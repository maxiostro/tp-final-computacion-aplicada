#!/bin/bash
if [ "$1" = "-help" ]; then
    echo "Usage: $0 <source> <destination>"
    exit 0
fi

SRC="${1%/}"
DST="${2%/}"

if [ -z "$SRC" ] || [ ! -d "$SRC" ] || [ ! -d "$DST" ] || ! mountpoint -q /backup_dir; then
    echo "Error: Source o destino inválidos, o /backup_dir no montado."
    exit 1
fi

tar -czf "$DST/$(basename "$SRC")_bkp_$(date +%Y%m%d).tar.gz" -C "$(dirname "$SRC")" "$(basename "$SRC")"
