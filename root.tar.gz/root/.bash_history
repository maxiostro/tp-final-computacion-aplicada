history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
cat /etc/resolv.conf v
powerofff
poweroff
sudo cat /etc/hash 
cd /usr/local/bin/
ls -ltr
ls -l
base64 -d -i < cat /etc/hash 
cat /etc/hash 
cat /etc/hash  > base64 -d -i
cat /etc/hash | base64 -d -i
rm /etc/hash 
chatrr -i /etc/hash 
cd /etc/
ls -l |has
ls -l |hash
ls -ltr 
chatrr +i hash 
chattr -i /etc/hash 
rm /etc/hash 
ls -l
reboot
history
shutdown now
cat /etc/resolv.conf
dhcp  -r && dhclient
dhclient -r && dhclient
ping 8.8.8.8
apt update
cat /etc/resolv.conf
nano /etc/resolv.conf
printf "nameserver 8.8.8.8" > /etc/resolv.conf
apt update
cat /etc/resolv.conf
printf "nameserver 8.8.8.8\n" > /etc/resolv.conf
chmod 644 /etc/resolv.conf
ping google.com
apt update
dhclient -r && dhclient
ping google.com
apt update
echo "deb http://deb.debian.org/debian bookworm main" > /etc/apt/sources.list
apt update
cat /etc/debian_version
apt install -y openssh-server
apt install nano
nano /etc/ssh/sshd_config
nano /etc/ssh/sshd_config
systemctl restart ssh
systemctl status ssh
nano /etc/ssh/sshd_config
sshd -t
nano /etc/ssh/sshd_config
systemctl restart ssh
apt upgrade
apt update && apt upgrade -y && apt full-upgrade -y
cp /etc/apt/sources.list /etc/apt/sources.list.bak
sed -i 's/bullseye/bookworm/g' /etc/apt/sources.list
apt update
apt upgrade --without-new-pkgs -y
apt full-upgrade -y
apt autoremove -y
ls -la /root /root/.ssh
mkdir -p /root/.ssh
nano /root/.ssh/authorized_keys
chmod 700 /root/.ssh && chmod 600 /root/.ssh/authorized_keys
cat /root/.ssh/authorized_keys
nano /etc/ssh/sshd_config
reboot
